import rclpy
from rclpy.node import Node
import requests

class NovelPubNode(Node):
    def __init__(self, node_name):
        super().__init__(node_name)
        self.get_logger().info(f'{node_name},start!')

    def download(self,url):
        respone = requests.get(url)
        respone.encoding = 'utf-8'
        text = respone.text
        self.get_logger().info(f'downlaod {url}, length of the text is {len(text)}')

def main():
    rclpy.init()
    node = NovelPubNode('novel_pub')
    node.download('http://0.0.0.0:8000/novel.txt')
    rclpy.spin(node)
    rclpy.shutdown()