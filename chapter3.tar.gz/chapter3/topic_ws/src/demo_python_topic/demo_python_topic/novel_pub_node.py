import rclpy
from rclpy.node import Node
import requests
from example_interfaces.msg import String
from queue import Queue


class NovelPubNode(Node):
    def __init__(self, node_name):
        super().__init__(node_name)
        self.get_logger().info(f'{node_name},start!')
        self.novels_queue_ = Queue()
        self.novel_publisher = self.create_publisher(String,'novel',10)
        self.create_timer(5,self.timer_callback)
        

    def download(self,url):
        respone = requests.get(url)
        respone.encoding = 'utf-8'
        text = respone.text
        self.get_logger().info(f'downlaod {url}, length of the text is {len(text)}')
        for line in text.splitlines():
            self.novels_queue_.put(line)

    def timer_callback(self):
        if self.novels_queue_.qsize()>0:
            line = self.novels_queue_.get()
            msg = String()
            msg.data = line
            self.novel_publisher.publish(msg)
            self.get_logger().info(f'published:{msg.data}')
        

def main():
    rclpy.init()
    node = NovelPubNode('novel_pub')
    node.download('http://127.0.0.1:8000/novel1.txt')
    rclpy.spin(node)
    rclpy.shutdown()